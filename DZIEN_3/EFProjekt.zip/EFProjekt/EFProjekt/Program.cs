﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFProjekt
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GARDENEntities db = new GARDENEntities();
            DaneZTabel(db);

            Console.ReadKey();
        }

        static void DaneZTabel(GARDENEntities dc)
        {
            var dane = from kl in dc.Klienci
                       from zam in dc.Zamówienia
                       where kl.IDKlienta == zam.IDKlienta && kl.Miasto == "Seattle"
                       select new
                       {
                           kl.Imię,
                           kl.Nazwisko,
                           kl.Miasto,
                           zam.IDZamówienia,
                           zam.KosztWysyłki
                       };
            foreach(var i in dane)
            { 
                Console.WriteLine($"Dane klienta -> imię: {i.Imię}, nazwisko: {i.Nazwisko}");
                Console.WriteLine($"Dabe zamówienia -> ID: {i.IDZamówienia}, koszt wysyłki = {i.KosztWysyłki} zł");
            }

        }
    }
}
